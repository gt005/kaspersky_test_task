from django.contrib import admin

from .models import Search, Path

admin.site.register(Search)
admin.site.register(Path)
